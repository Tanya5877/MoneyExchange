package za.co.me.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import za.co.me.Entity.ExchangeRate;

public interface ExchangeRateRepository extends JpaRepository<ExchangeRate, Long> {
    Optional<ExchangeRate> findByFromCurrencyAndToCurrency(za.co.me.Entity.Currency fromCurrency, za.co.me.Entity.Currency toCurrency);
}



