package za.co.me.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import za.co.me.Entity.ExchangeRate;
import za.co.me.Repository.ExchangeRateRepository;



import java.util.List;


@Service
public class ExchangeRateService {

    @Autowired
    private ExchangeRateRepository exchangeRateRepository;

    @Autowired
    private CurrencyService currencyService;

    @Transactional(readOnly = true)
    public List<ExchangeRate> getAllExchangeRates() {
        return exchangeRateRepository.findAll();
    }

    @Transactional(readOnly = true)
    public ExchangeRate getExchangeRateById(Long id) {
        return exchangeRateRepository.findById(id)
        		 .orElseThrow(() -> new RuntimeException( "Currency not found by id "+ id));}


   
    @Transactional
    public ExchangeRate createExchangeRate(ExchangeRate exchangeRate) {
        za.co.me.Entity.Currency fromCurrency = exchangeRate.getFromCurrency();
        za.co.me.Entity.Currency toCurrency = exchangeRate.getToCurrency();

        currencyService.getCurrencyById(fromCurrency.getId()); 
        currencyService.getCurrencyById(toCurrency.getId()); 

        return exchangeRateRepository.save(exchangeRate);
    }

    @Transactional
    public ExchangeRate updateExchangeRate(Long id, ExchangeRate updatedExchangeRate) {
        ExchangeRate existingExchangeRate = getExchangeRateById(id);

        existingExchangeRate.setRate(updatedExchangeRate.getRate());

        return exchangeRateRepository.save(existingExchangeRate);
    }

    @Transactional
    public void deleteExchangeRate(Long id) {
        ExchangeRate exchangeRate = getExchangeRateById(id);
        exchangeRateRepository.delete(exchangeRate);
    }
}



