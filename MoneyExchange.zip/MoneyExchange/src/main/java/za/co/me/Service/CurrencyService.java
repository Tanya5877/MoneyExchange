package za.co.me.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import jakarta.persistence.EntityNotFoundException;
import za.co.me.Repository.CurrencyRepository;

import java.util.List;
import java.util.Currency;

@Service
public class CurrencyService {

    @Autowired
    private CurrencyRepository currencyRepository;

    @Transactional(readOnly = true)
    public List<Currency> getAllCurrencies() {
        return currencyRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Currency getCurrencyById(Long id) {
        return currencyRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException( "Currency not found by id "+ id));
    }

    @Transactional(readOnly = true)
    public Currency getCurrencyByCode(String code) {
        return currencyRepository.findByCode(code)
                .orElseThrow(() -> new EntityNotFoundException("Currency not found with code: " + code));

                        
    }


    @Transactional
    public Currency createCurrency(Currency currency) {
        return currencyRepository.save(currency);
    }

    @Transactional
    public void deleteCurrency(Long id) {
        Currency currency = getCurrencyById(id);
        currencyRepository.delete(currency);
    }
}




