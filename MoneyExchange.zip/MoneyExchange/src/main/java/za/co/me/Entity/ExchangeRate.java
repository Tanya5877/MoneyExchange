package za.co.me.Entity;

import java.math.BigDecimal;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
	public class ExchangeRate {
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    @ManyToOne
	    @JoinColumn(name = "from_currency_id", nullable = false)
	    private Currency fromCurrency;

	    @ManyToOne
	    @JoinColumn(name = "to_currency_id", nullable = false)
	    private Currency toCurrency;

	    private BigDecimal rate;


	    public ExchangeRate() {
	    }

	    public ExchangeRate(Currency fromCurrency, Currency toCurrency, BigDecimal rate) {
	        this.fromCurrency = fromCurrency;
	        this.toCurrency = toCurrency;
	        this.rate = rate;
	    }

	    

	    public Long getId() {
	        return id;
	    }

	    public void setId(Long id) {
	        this.id = id;
	    }

	    public Currency getFromCurrency() {
	        return fromCurrency;
	    }

	    public void setFromCurrency(Currency fromCurrency) {
	        this.fromCurrency = fromCurrency;
	    }

	    public Currency getToCurrency() {
	        return toCurrency;
	    }

	    public void setToCurrency(Currency toCurrency) {
	        this.toCurrency = toCurrency;
	    }

	    public BigDecimal getRate() {
	        return rate;
	    }

	    public void setRate(BigDecimal rate) {
	        this.rate = rate;
	    }

	    // Override toString() if needed

	    @Override
	    public String toString() {
	        return "ExchangeRate{" +
	                "id=" + id +
	                ", fromCurrency=" + fromCurrency +
	                ", toCurrency=" + toCurrency +
	                ", rate=" + rate +
	                '}';
	    }
	}


	
	


