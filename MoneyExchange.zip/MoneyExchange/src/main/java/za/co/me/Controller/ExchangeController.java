package za.co.me.Controller;

import java.util.Currency;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import za.co.me.Entity.ExchangeRate;
import za.co.me.Service.CurrencyService;
import za.co.me.Service.ExchangeRateService;

@RestController
@RequestMapping("/api/exchange")
public class ExchangeController {
    @Autowired
    private CurrencyService currencyService;

    @Autowired
    private ExchangeRateService exchangeRateService;

    @GetMapping("/currencies")
    public List<Currency> getAllCurrencies() {
        return currencyService.getAllCurrencies();
    }

    @GetMapping("/currencies/{id}")
    public ResponseEntity<Currency> getCurrencyById(@PathVariable Long id) {
        Currency currency = currencyService.getCurrencyById(id);
        return ResponseEntity.ok(currency);
    }

    @PostMapping("/currencies")
    public ResponseEntity<Currency> createCurrency(@RequestBody Currency currency) {
        Currency createdCurrency = currencyService.createCurrency(currency);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdCurrency);
    }

    @DeleteMapping("/currencies/{id}")
    public ResponseEntity<Void> deleteCurrency(@PathVariable Long id) {
        currencyService.deleteCurrency(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/exchange-rates")
    public List<ExchangeRate> getAllExchangeRates() {
        return exchangeRateService.getAllExchangeRates();
    }

    @GetMapping("/exchange-rates/{id}")
    public ResponseEntity<ExchangeRate> getExchangeRateById(@PathVariable Long id) {
        ExchangeRate exchangeRate = exchangeRateService.getExchangeRateById(id);
        return ResponseEntity.ok(exchangeRate);
    }

    

    @PostMapping("/exchange-rates")
    public ResponseEntity<ExchangeRate> createExchangeRate(@RequestBody ExchangeRate exchangeRate) {
        ExchangeRate createdExchangeRate = exchangeRateService.createExchangeRate(exchangeRate);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdExchangeRate);
    }

    @PutMapping("/exchange-rates/{id}")
    public ResponseEntity<ExchangeRate> updateExchangeRate(
            @PathVariable Long id, @RequestBody ExchangeRate updatedExchangeRate) {
        ExchangeRate updatedRate = exchangeRateService.updateExchangeRate(id, updatedExchangeRate);
        return ResponseEntity.ok(updatedRate);
    }

    @DeleteMapping("/exchange-rates/{id}")
    public ResponseEntity<Void> deleteExchangeRate(@PathVariable Long id) {
        exchangeRateService.deleteExchangeRate(id);
        return ResponseEntity.noContent().build();
    }
}
