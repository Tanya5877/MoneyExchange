package za.co.me;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoneyExchangeApplicationTests {

	@Test
	void contextLoads() {
	}

}
